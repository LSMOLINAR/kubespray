# UOS Linux

UOS Linux(UnionTech OS Server 20) is supported with docker and containerd runtimes.

**Note:** that UOS Linux is not currently covered in kubespray CI and
support for it is currently considered experimental.

There are no special considerations for using UOS Linux as the target OS
for Kubespray deployments.
